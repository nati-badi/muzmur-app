N1.c
